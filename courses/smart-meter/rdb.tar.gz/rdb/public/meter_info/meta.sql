CREATE TABLE meter_info (
	meter_id VARCHAR(50) NOT NULL,
	install_date DATE NULL,
	voltage_level VARCHAR(20) NULL,
	manufacturer VARCHAR(50) NULL,
	status VARCHAR(20) NULL,
	area_id VARCHAR(20) NULL,
	user_id VARCHAR(50) NULL,
	CONSTRAINT "primary" PRIMARY KEY (meter_id ASC),
	FAMILY "primary" (meter_id, install_date, voltage_level, manufacturer, status, area_id, user_id)
);
