CREATE TABLE user_info (
	user_id VARCHAR(50) NOT NULL,
	user_name VARCHAR(100) NULL,
	address VARCHAR(200) NULL,
	contact VARCHAR(20) NULL,
	CONSTRAINT "primary" PRIMARY KEY (user_id ASC),
	FAMILY "primary" (user_id, user_name, address, contact)
);
