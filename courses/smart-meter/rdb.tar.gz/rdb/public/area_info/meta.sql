CREATE TABLE area_info (
	area_id VARCHAR(20) NOT NULL,
	area_name VARCHAR(100) NULL,
	manager VARCHAR(50) NULL,
	region VARCHAR(50) NULL,
	CONSTRAINT "primary" PRIMARY KEY (area_id ASC),
	FAMILY "primary" (area_id, area_name, manager, region)
);
