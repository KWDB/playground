CREATE TABLE alarm_rules (
	rule_id INT8 NOT NULL DEFAULT unique_rowid(),
	rule_name VARCHAR(100) NULL,
	metric VARCHAR(50) NULL,
	operator VARCHAR(10) NULL,
	threshold FLOAT8 NULL,
	severity VARCHAR(20) NULL,
	notify_method VARCHAR(50) NULL,
	CONSTRAINT "primary" PRIMARY KEY (rule_id ASC),
	FAMILY "primary" (rule_id, rule_name, metric, operator, threshold, severity, notify_method)
);
