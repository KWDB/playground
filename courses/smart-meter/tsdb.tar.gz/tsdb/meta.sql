CREATE TS DATABASE tsdb;
CREATE TABLE meter_data (
	ts TIMESTAMPTZ(3) NOT NULL,
	voltage FLOAT8 NULL,
	current FLOAT8 NULL,
	power FLOAT8 NULL,
	energy FLOAT8 NULL
) TAGS (
	meter_id VARCHAR(50) NOT NULL ) PRIMARY TAGS(meter_id)
	retentions 0s
	activetime 0d
	partition interval 10d;
